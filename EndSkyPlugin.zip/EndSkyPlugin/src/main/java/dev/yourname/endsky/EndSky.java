package dev.yourname.endsky;

import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketType;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.lang.reflect.InvocationTargetException;

public class EndSky extends JavaPlugin {

    private static final String TARGET_WORLD = "PortalWorld";

    @Override
    public void onEnable() {
        Bukkit.getOnlinePlayers().forEach(this::checkAndSend);
        Bukkit.getPluginManager().registerEvents(new org.bukkit.event.Listener() {
            @org.bukkit.event.EventHandler
            public void onJoin(org.bukkit.event.player.PlayerJoinEvent event) {
                checkAndSend(event.getPlayer());
            }

            @org.bukkit.event.EventHandler
            public void onWorldChange(org.bukkit.event.player.PlayerChangedWorldEvent event) {
                checkAndSend(event.getPlayer());
            }
        }, this);
    }

    private void checkAndSend(Player player) {
        World world = player.getWorld();
        if (world.getName().equalsIgnoreCase(TARGET_WORLD)) {
            sendFakeEndDimension(player);
        }
    }

    private void sendFakeEndDimension(Player player) {
        PacketContainer packet = new PacketContainer(PacketType.Play.Server.RESPAWN);
        packet.getIntegers().write(0, 1); // The End dimension id
        packet.getUUIDs().write(0, player.getWorld().getUID());
        packet.getStrings().write(0, "minecraft:the_end");
        packet.getBooleans().write(0, false); // isDebug
        packet.getBooleans().write(1, false); // isFlat

        try {
            ProtocolLibrary.getProtocolManager().sendServerPacket(player, packet);
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }
}
